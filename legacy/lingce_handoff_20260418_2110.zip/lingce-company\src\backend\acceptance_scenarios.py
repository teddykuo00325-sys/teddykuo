# -*- coding: utf-8 -*-
"""
客戶驗收中心 - 驗收場景模組
對應 addwii 五大構面 + microjet 五大場景
每個場景都輸出 AI Agent Workflow 步驟 (for 前端視覺化)
"""
import os, re, csv, json, glob, time, hashlib, threading, queue, functools
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

# ============================================================
# PII 去識別化
# ============================================================
CSV_DIR = r'C:\Users\B00325\Desktop\10CSVfile'
AUDIT_LOG = os.path.join(os.path.dirname(__file__), '..', '..', 'chat_logs', 'acceptance_audit.jsonl')

def _unicode_escape_to_name(s: str) -> str:
    """把 _U4e03_U6a13 還原回 七樣 (僅供內部使用，不對外輸出)"""
    def rep(m):
        try:
            return chr(int(m.group(1), 16))
        except Exception:
            return m.group(0)
    return re.sub(r'_U([0-9a-fA-F]{4})', rep, s)

def _mask_name(name: str) -> str:
    """姓名去識別化：保留首字 + **"""
    real = _unicode_escape_to_name(name)
    if not real:
        return '***'
    if len(real) == 1:
        return real + '*'
    if re.match(r'^[A-Za-z]+$', real):
        return real[0] + '*' * (len(real) - 1)
    return real[0] + '*' * (len(real) - 1)

def _hash_id(s: str) -> str:
    return 'U-' + hashlib.md5(s.encode('utf-8')).hexdigest()[:8]

# 非同步稽核寫入：API 不再等磁碟 flush，延遲從 ~200ms 降到 <1ms
_AUDIT_Q: "queue.Queue[str]" = queue.Queue()

def _audit_worker():
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    while True:
        line = _AUDIT_Q.get()
        try:
            with open(AUDIT_LOG, 'a', encoding='utf-8') as f:
                f.write(line)
        except Exception:
            pass

threading.Thread(target=_audit_worker, daemon=True).start()

def _audit(action: str, user: str, detail: dict):
    line = json.dumps({
        'ts': datetime.now().isoformat(timespec='seconds'),
        'action': action, 'user': user, 'detail': detail
    }, ensure_ascii=False) + '\n'
    _AUDIT_Q.put(line)

# ============================================================
# Agent Workflow helper
# ============================================================
def _step(name, desc, status='done', data=None):
    return {'name': name, 'desc': desc, 'status': status, 'data': data or {}}

# ============================================================
# 場景 1: 產品 Q&A (addwii 構面一 15pts / microjet A)
# ============================================================
PRODUCT_KB = {
    'addwii': {
        'name': 'addwii 場域無塵室 Clean Room 系列',
        'home_url': 'https://addwii.com/',
        'features': [
            '類醫療級潔淨標準',
            'AI 智能監測 + 24 小時自動淨化',
            '六大場域完整產品線（嬰兒/廚房/浴室/客廳/臥室/餐廳）',
            'PM2.5 接近 0，有毒物質過濾',
            '針對特定空間場景優化（油煙/甲醛/蒸氣/睡眠）',
        ],
        'target': '關心家人健康的家庭：嬰幼兒、孕婦、過敏體質、銀髮長輩；重視烹飪、睡眠品質的使用者',
        'warranty': '主機 2 年 / 濾網耗材建議每 6~12 個月更換 / 到府維修服務',
        'price': '依場域與空間大小報價，詳情請洽 addwii 官網預約',
        'faq': {
            '有哪些產品': 'addwii 提供六款場域專用無塵室：①嬰兒無塵室 ②廚房無塵室 ③浴室無塵室 ④客廳無塵室 ⑤臥室無塵室 ⑥餐廳無塵室。',
            '嬰兒無塵室適合誰': '0~3 歲嬰幼兒與孕婦使用，達到類醫療級無塵標準，AI 智能監測 PM2.5 近零。',
            '廚房無塵室能做什麼': '過濾烹飪油煙與 PM2.5，保護料理者呼吸道；特別適合烘焙、長時間烹煮族群。',
            '浴室無塵室特色': '杜絕甲醛污染、處理高濕蒸氣環境、隔離清潔劑揮發等有毒物質。',
            '臥室無塵室重點': '目標 PM2.5=0，過濾有害物質，創造深度睡眠環境。',
            '客廳無塵室為誰設計': '家庭聚集核心空間，守護全家人活動時的呼吸健康。',
            '餐廳無塵室用途': '用餐環境空氣保護，讓團圓時刻吃得更安心。',
            '如何選擇適合的產品': '依主要活動場域選擇：有嬰幼兒首推嬰兒無塵室；外食少自炊多選廚房；睡眠品質差選臥室。也可多場域組合。',
            '與一般空氣清淨機差異': 'addwii 採類醫療無塵室設計思維，針對場域情境（油煙/甲醛/蒸氣）深度優化，非通用產品。',
            '如何聯繫與體驗': '請造訪 addwii 官網 https://addwii.com 了解產品並預約諮詢。',
        }
    },
    'microjet': {
        'name': 'MicroJet 微噴科技 — MEMS 壓電微流體技術領導品牌',
        'home_url': 'https://www.microjet.com.tw/en/',
        'features': [
            '累積 1,600+ 件微泵浦與 MEMS 技術專利',
            '2018 年全台專利排名第 10',
            '子品牌 CurieJet® 專注環境感測器模組',
            '核心技術：壓電微流體、MEMS、噴墨印頭',
            '產品涵蓋 3D 列印、感測器、微型泵浦、血壓模組',
            '世界最小車用環境感測器',
        ],
        'target': '3D 列印產業、環境監測設備商、穿戴式裝置品牌、車用電子、醫療器材（血壓計）、工業噴墨應用',
        'warranty': '視產品線而定；工業產品標配 1 年保固 + 年度維護合約',
        'price': '工業/模組類產品依配置報價，請洽業務窗口',
        'faq': {
            '有哪些產品線': {
                'text': 'MicroJet 四大產品線：①熱泡噴墨印頭與墨水 ②ComeTrue® 3D 列印機（T10 全彩粉末 / M10 陶瓷） ③CurieJet® 環境感測器（P710/P760） ④壓電微型泵浦與鼓風機、血壓模組。',
                'refs': [
                    {'title':'MicroJet 企業官網','url':'https://www.microjet.com.tw/en/'},
                    {'title':'CurieJet® 感測器','url':'https://www.curiejet.com/en/'},
                ]
            },
            'ComeTrue T10 是什麼': {
                'text': 'ComeTrue® T10 全彩粉末基 3D 列印機，可印真實全彩色模型，廣泛用於文創與原型製作。',
                'refs': [{'title':'T10 產品規格頁','url':'https://www.cometrue3d.com/en/product/detail/t10-full-color-3d-printer'}]
            },
            'ComeTrue M10 是什麼': {
                'text': 'ComeTrue® M10 是黏結劑噴射 (binder jetting) 陶瓷 3D 列印機，適合工業用陶瓷零件與藝術品。',
                'refs': [{'title':'M10 產品規格頁','url':'https://www.cometrue3d.com/en/product/detail/m10-ceramic-binder-jetting-3d-printer'}]
            },
            'CurieJet P710 規格': {
                'text': 'P710 為 PM 顆粒物感測器模組，29×29×7.2 mm 世界最小，量測 PM1.0/PM2.5/PM10，雷射 Mie 散射偵測，I2C 介面。',
                'refs': [{'title':'P710/P760 Datasheet 頁','url':'https://www.curiejet.com/en/product/particle-voc-index-barometric-pressure-sensor/environmental-sensor-modules'}]
            },
            'CurieJet P760 規格': {
                'text': 'P760 為顆粒物 + 氣體整合模組，同尺寸 29×29×7.2 mm，整合 BME688 偵測 VOC（含甲醛），IAQ 指數 0~500，另含氣壓感測供高度/氣象應用。',
                'refs': [{'title':'P710/P760 Datasheet 頁','url':'https://www.curiejet.com/en/product/particle-voc-index-barometric-pressure-sensor/environmental-sensor-modules'}]
            },
            '感測器應用場景': {
                'text': '室內空氣品質監控、穿戴式裝置、智慧家電、車用環境監測、氣象/GPS 高度輔助。',
                'refs': [
                    {'title':'環境感測應用','url':'https://www.curiejet.com/en/product/environmental-sensor-applications'},
                    {'title':'車用環境感測器','url':'https://www.curiejet.com/en/product/car'},
                ]
            },
            '壓電微泵浦用途': {
                'text': '靜音液體/氣體微泵與微型鼓風機，應用於血壓計、醫療吸引、化妝品點膠、香氛擴散、電子冷卻等。',
                'refs': [
                    {'title':'微型泵浦產品','url':'https://www.curiejet.com/en/product/micro-pump'},
                    {'title':'空氣泵與微型鼓風機','url':'https://www.curiejet.com/en/product/micro-pump/air-pump-and-micro-blower'},
                    {'title':'壓電式液體微泵','url':'https://www.curiejet.com/en/product/micro-pump/piezo-electric-liquid-micropump'},
                ]
            },
            '噴墨印頭技術': {
                'text': '熱泡式 (thermal bubble) 噴墨印頭，相容多種墨水，可客製工業應用模組。',
                'refs': [
                    {'title':'噴墨印頭技術頁','url':'https://www.microjet.com.tw/en/technology/inkjet-printheads'},
                    {'title':'噴墨墨盒產品','url':'https://www.microjet.com.tw/en/product/inkjet-cartridges'},
                ]
            },
            '血壓模組特色': {
                'text': '壓電式穿戴型靜音血壓計模組，取代傳統馬達充氣，適合連續監測型血壓產品。',
                'refs': [
                    {'title':'血壓監測產品線','url':'https://www.curiejet.com/en/product/blood-pressure-monitoring'},
                    {'title':'穿戴式靜音血壓模組','url':'https://www.curiejet.com/en/product/blood-pressure-monitoring/wearable-silent-blood-pressure-monitor-module'},
                ]
            },
            '防水防塵': {
                'text': 'G200GAS 變體提供防水防塵等級，適合戶外/惡劣環境應用。',
                'refs': [{'title':'環境感測器模組','url':'https://www.curiejet.com/en/product/particle-voc-index-barometric-pressure-sensor/environmental-sensor-modules'}]
            },
            '專利與競爭力': '累計超過 1,600 件專利，多為發明專利，2018 年台灣專利第 10 名；技術壁壘高。',
            '如何聯繫與採購': {
                'text': '官網可預約技術洽談與樣品申請。',
                'refs': [
                    {'title':'MicroJet 企業官網','url':'https://www.microjet.com.tw/en/'},
                    {'title':'CurieJet® 感測器官網','url':'https://www.curiejet.com/en/'},
                ]
            },
        }
    }
}

# 預建關鍵字倒排索引：O(n) 掃描 → O(1) 查詢
_FAQ_INDEX = {}
_PUNCT_RE = re.compile(r'[\s\.,;:!?？！，。；：、「」『』《》()（）\[\]【】\-_/\\]+')

def _normalize(text: str) -> str:
    """查詢正規化：小寫 + 去標點空白，讓 bigram 不受大小寫/標點影響"""
    return _PUNCT_RE.sub('', (text or '').lower())

def _bigrams(text: str) -> set:
    t = _normalize(text)
    return set(t[i:i+2] for i in range(len(t)-1)) if len(t) >= 2 else ({t} if t else set())

def _faq_entry(a):
    """統一 FAQ 項目為 {text, refs}；舊字串格式自動適配"""
    if isinstance(a, dict):
        return {'text': a.get('text',''), 'refs': a.get('refs') or []}
    return {'text': str(a), 'refs': []}

def _build_faq_index():
    _FAQ_INDEX.clear()
    for customer, kb in PRODUCT_KB.items():
        idx = []
        for q, raw in kb.get('faq', {}).items():
            entry = _faq_entry(raw)
            idx.append((q, entry, _bigrams(q)))
        _FAQ_INDEX[customer] = idx
_build_faq_index()

@functools.lru_cache(maxsize=256)
def _qa_compute(customer: str, question: str):
    """純函式結果快取；回傳 answer 純文字 + refs 結構化參考連結"""
    kb = PRODUCT_KB.get(customer, {})
    index = _FAQ_INDEX.get(customer, [])
    q_tokens = _bigrams(question)
    hits = []
    for q, entry, toks in index:
        score = len(q_tokens & toks)
        if score > 0:
            hits.append((score, q, entry))
    hits.sort(reverse=True)
    refs = []  # 累積的 datasheet / 產品頁連結（自動去重）
    seen_urls = set()
    def _add_ref(r, from_q=None):
        url = r.get('url')
        if not url or url in seen_urls: return
        seen_urls.add(url)
        refs.append({'title': r.get('title') or url, 'url': url, 'from': from_q})

    if hits:
        top = hits[:2]
        related = [q for _, q, _ in hits[2:5]]
        lines = [f'【{kb.get("name","-")}】（依知識庫命中 {len(hits)} 筆）', '']
        for _, q, entry in top:
            lines.append(f'▸ {q}')
            lines.append(f'  {entry["text"]}')
            for r in entry.get('refs', []):
                _add_ref(r, from_q=q)
                lines.append(f'  📄 {r.get("title","規格書")}：{r.get("url","")}')
            lines.append('')
        if related:
            lines.append('── 您可能還想問 ──')
            for q in related:
                lines.append(f'  • {q}')
        answer = '\n'.join(lines).rstrip()
        matched = len(hits)
    else:
        lines = [
            f'【{kb.get("name","未知產品")}】', '',
            '✨ 主要特色',
            *[f'  • {f}' for f in kb.get('features', [])], '',
            f'🎯 適用對象：{kb.get("target","-")}',
            f'🛡️ 保固：{kb.get("warranty","-")}',
            f'💰 價格：{kb.get("price","-")}',
        ]
        if kb.get('home_url'):
            lines.append(f'🌐 官網：{kb["home_url"]}')
            _add_ref({'title': '產品官網', 'url': kb['home_url']})
        lines += ['',
            f'── 常見問題 (共 {len(index)} 筆，請試著問這些)──',
            *[f'  • {q}' for q, _, _ in index],
        ]
        answer = '\n'.join(lines)
        matched = 0
    return {'answer': answer, 'matched': matched, 'kb_name': kb.get('name', ''),
            'faq_total': len(index), 'refs': refs}

def product_qa(customer: str, question: str, user: str = 'guest'):
    r = _qa_compute(customer, question or '')
    steps = [
        _step('1. 接收問題', f'客戶: {customer} / 提問: {question}'),
        _step('2. 意圖分類', '判斷屬於產品規格/保固/FAQ 類別'),
        _step('3. 倒排索引檢索', f'bigram 比對命中 {r["matched"]}/{r["faq_total"]} 筆 FAQ'),
        _step('4. 組合回覆', 'TopK=3 依相關度排序'),
        _step('5. 附加 Datasheet', f'引用 {len(r["refs"])} 個官方規格連結' if r['refs'] else '無特定規格連結'),
        _step('6. 稽核紀錄', '非同步寫入 acceptance_audit.jsonl'),
    ]
    _audit('product_qa', user, {'customer': customer, 'q': question})
    return {'answer': r['answer'], 'workflow': steps, 'kb': r['kb_name'], 'refs': r['refs']}

# ============================================================
# 場景 2: 客戶回饋分析 (addwii 構面二 25pts / microjet B,D)
# ============================================================
def analyze_feedback(records: list, user: str = 'guest'):
    """
    records: [{'id','date','customer','content'}]
    回傳情緒標註 + 問題分類 + 改善建議
    """
    pos_kw = ['滿意', '好用', '棒', '感謝', '喜歡', '穩定', '推薦']
    neg_kw = ['爛', '故障', '壞', '慢', '當機', '不準', '誤報', '不滿', '客訴', '退']
    cat_map = {
        '硬體': ['感測器', '噴頭', '主機', '風扇', '電源', '連線', '斷線'],
        '軟體': ['APP', 'app', '儀表板', '介面', '閃退', '更新'],
        '服務': ['客服', '到府', '維修', '回覆', '等待'],
        '準確度': ['不準', '誤報', '漂移', '校正'],
    }
    out = []
    stats = defaultdict(int)
    for r in records:
        content = r.get('content', '')
        score = 0
        for k in pos_kw:
            if k in content: score += 1
        for k in neg_kw:
            if k in content: score -= 1
        sentiment = '正面' if score > 0 else ('負面' if score < 0 else '中性')
        cats = []
        for c, kws in cat_map.items():
            if any(k in content for k in kws):
                cats.append(c)
        suggestion = ''
        if sentiment == '負面':
            if '硬體' in cats: suggestion = '派工單 → 現場工程師 24h 內到府'
            elif '軟體' in cats: suggestion = '升級提示 + 遠端協助'
            elif '服務' in cats: suggestion = '主管回電致歉 + 服務券'
            elif '準確度' in cats: suggestion = '遠端校正 + 回寄感測模組檢測'
            else: suggestion = '客服主管 1:1 聯繫'
        out.append({
            'id': r.get('id'),
            'customer': _mask_name(r.get('customer', '')),
            'sentiment': sentiment,
            'categories': cats or ['其他'],
            'suggestion': suggestion,
        })
        stats[sentiment] += 1
        for c in cats or ['其他']:
            stats[c] += 1

    workflow = [
        _step('1. 匯入客訴資料', f'{len(records)} 筆客戶服務紀錄'),
        _step('2. PII 去識別化', '客戶姓名遮罩為 X**'),
        _step('3. 情緒標註', f'正面 {stats["正面"]} / 中性 {stats["中性"]} / 負面 {stats["負面"]}'),
        _step('4. 問題分類', '依硬體/軟體/服務/準確度歸類'),
        _step('5. 行動派工', '負面案件自動生成派工建議'),
        _step('6. 稽核紀錄', '寫入 acceptance_audit.jsonl'),
    ]
    _audit('feedback_analysis', user, {'n': len(records)})
    return {'records': out, 'stats': dict(stats), 'workflow': workflow}

# 預設示範資料 (可直接被前端呼叫)
DEMO_FEEDBACK = [
    {'id':'CS-001','date':'2026-04-10','customer':'_U738b_U6dd1_U60e0','content':'感測器用了三個月就不準，PM2.5 顯示 0 但外面明顯有油煙，已經客訴兩次了還沒解決'},
    {'id':'CS-002','date':'2026-04-11','customer':'Simone','content':'APP 儀表板 UI 很好用，趨勢圖做得很棒，整體很滿意，推薦朋友了'},
    {'id':'CS-003','date':'2026-04-12','customer':'_U6797_U7d2b_U9234','content':'夜間風扇聲音偏大，希望有靜音模式；不過客服回覆很快，感謝'},
]

# ============================================================
# 場景 3: B2B 提案生成 (addwii 構面三 20pts / microjet C)
# ============================================================
def generate_proposal(customer: str, client_profile: dict, user: str = 'guest'):
    """
    client_profile: {'industry','scale','pain_point','budget'}
    """
    kb = PRODUCT_KB.get(customer, {})
    ind = client_profile.get('industry', '一般企業')
    scale = client_profile.get('scale', '50 人')
    pain = client_profile.get('pain_point', '-')
    budget = client_profile.get('budget', '未提供')

    solutions = {
        'addwii': [
            '部署 Home Clean Room 商用版 10 台於會議室/茶水間',
            '雲端儀表板串接 HR 健康指標儀表',
            '空調連動：PM2.5 > 35 自動提升換氣',
        ],
        'microjet': [
            '導入 MJ-3200 工業噴印機 2 台於主產線與備援',
            '整合 MES：每小時產量回報 + 耗材預測',
            '維運合約：年度噴頭 2 次校保 + 24h 到場 SLA',
        ]
    }.get(customer, [])

    proposal = {
        'title': f'【凌策 x {customer.upper()}】{ind} 產業智慧化提案',
        'client': ind,
        'scale': scale,
        'pain_point': pain,
        'budget': budget,
        'solution': solutions,
        'roi': {
            '預估導入期': '6~8 週',
            '節省人力': '每月 ~40 工時',
            '預估投資回收': '14~18 個月',
        },
        'next_step': ['安排 POC 試用 2 週', '提供正式報價單', '簽訂 MSA']
    }
    workflow = [
        _step('1. 解析客戶需求', f'{ind} / {scale} / 痛點: {pain}'),
        _step('2. 產品配對', f'主推 {kb.get("name", "N/A")}'),
        _step('3. 方案設計', f'輸出 {len(solutions)} 條解決方案'),
        _step('4. ROI 估算', '導入期/節省工時/回收週期'),
        _step('5. 下一步規劃', '列出 POC → 報價 → 合約路徑'),
    ]
    _audit('proposal', user, {'customer': customer, 'ind': ind})
    return {'proposal': proposal, 'workflow': workflow}

# ============================================================
# 場景 4: 內容行銷 (addwii 構面四 15pts)
# ============================================================
def generate_content(topic: str, channel: str = 'FB', user: str = 'guest'):
    templates = {
        'FB': '【{topic}】\n你家空氣品質真的乾淨嗎？🌫️\nHome Clean Room 7 合一感測，PM2.5 / CO2 / VOC 一次掌握。\n#室內空氣 #健康生活 #凌策智能\n👉 點連結免費試用 7 天',
        'IG': '✨ {topic} ✨\n呼吸這件事，值得更被在意。\nHome Clean Room 讓每一口空氣都有數據。\n.\n.\n#cleanair #smarthome #凌策',
        'LinkedIn': '【Industry Insight】{topic}\n辦公室 CO2 長期 >1000ppm 會顯著降低員工認知效能。\n凌策 Home Clean Room 商用版已協助 30+ 企業優化室內環境。\n歡迎預約 Demo。',
        'Blog': '# {topic}\n\n## 為什麼室內空氣值得關注？\n研究指出，現代人 90% 時間待在室內...\n\n## Home Clean Room 如何解決\n1. 7 合一感測模組\n2. 30 天趨勢雲端儀表板\n3. 與空調/新風系統聯動\n\n## 小結\n乾淨空氣不再是感覺，而是數據。'
    }
    content = templates.get(channel, templates['FB']).format(topic=topic)
    workflow = [
        _step('1. 主題解析', f'主題: {topic} / 通路: {channel}'),
        _step('2. TA 定位', 'B2C / B2B 受眾調性判斷'),
        _step('3. 文案生成', f'套用 {channel} 模板與 hashtag 策略'),
        _step('4. 合規檢查', '品牌用詞 / 誇大宣稱過濾'),
    ]
    _audit('content', user, {'topic': topic, 'channel': channel})
    return {'content': content, 'workflow': workflow}

# ============================================================
# 場景 5: CSV 感測器分析 (addwii 構面五 25pts / microjet E)
# ============================================================
def _parse_filename(fn: str):
    """從 roomId-143-houseId-26-Simone-2026-04-15-sensor30d.csv 解析"""
    base = os.path.basename(fn)
    m = re.match(r'roomId-(\d+)-houseId-(\d+)-(.+?)-\d{4}-\d{2}-\d{2}-sensor30d\.csv', base)
    if not m:
        return {'room': '?', 'house': '?', 'user_raw': base, 'user_masked': '***', 'user_id': _hash_id(base)}
    room, house, user_raw = m.group(1), m.group(2), m.group(3)
    return {
        'room': room,
        'house': house,
        'user_raw': user_raw,  # 不對外輸出
        'user_masked': _mask_name(user_raw),
        'user_id': _hash_id(user_raw),
    }

def _summarize_csv(path: str, max_rows: int = 500000):
    """讀單一 CSV，輸出空氣品質統計（用 csv.reader + 索引，比 DictReader 快 2-3x）"""
    rows_cnt = 0
    pm25_max = 0.0; pm25_sum = 0.0; pm25_over = 0
    co2_max  = 0.0; co2_sum  = 0.0; co2_over  = 0
    voc_max  = 0.0; voc_sum  = 0.0
    t_max = -999.0; t_min = 999.0; t_sum = 0.0
    h_max = 0.0;    h_min = 999.0; h_sum = 0.0
    power_on = 0
    with open(path, 'r', encoding='utf-8', errors='ignore', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if not header: return {'rows': 0}
        idx = {name: i for i, name in enumerate(header)}
        i_t  = idx.get('temperature', -1)
        i_h  = idx.get('humidity', -1)
        i_p  = idx.get('pm25', -1)
        i_v  = idx.get('voc_level', -1)
        i_c  = idx.get('co2', -1)
        i_pw = idx.get('ZP-power_status', -1)
        for row in reader:
            if rows_cnt >= max_rows: break
            try:
                pm = float(row[i_p] or 0) if i_p >= 0 else 0
                co = float(row[i_c] or 0) if i_c >= 0 else 0
                vo = float(row[i_v] or 0) if i_v >= 0 else 0
                t  = float(row[i_t] or 0) if i_t >= 0 else 0
                h  = float(row[i_h] or 0) if i_h >= 0 else 0
            except (ValueError, IndexError):
                continue
            rows_cnt += 1
            if pm > pm25_max: pm25_max = pm
            pm25_sum += pm
            if pm > 35: pm25_over += 1
            if co > co2_max: co2_max = co
            co2_sum += co
            if co > 1000: co2_over += 1
            if vo > voc_max: voc_max = vo
            voc_sum += vo
            if t > t_max: t_max = t
            if t < t_min: t_min = t
            t_sum += t
            if h > h_max: h_max = h
            if h < h_min: h_min = h
            h_sum += h
            if i_pw >= 0 and rows_cnt <= len(row) and row[i_pw] == 'on':
                power_on += 1
    n = max(rows_cnt, 1)
    return {
        'rows': rows_cnt,
        'pm25_avg': round(pm25_sum/n, 2), 'pm25_max': round(pm25_max, 2),
        'pm25_over35_ratio': round(pm25_over/n*100, 1),
        'co2_avg': round(co2_sum/n, 2), 'co2_max': round(co2_max, 2),
        'co2_over1000_ratio': round(co2_over/n*100, 1),
        'voc_avg': round(voc_sum/n, 2), 'voc_max': round(voc_max, 2),
        'temp_avg': round(t_sum/n, 2),
        'temp_range': f'{round(t_min,1)} ~ {round(t_max,1)}°C',
        'hum_avg': round(h_sum/n, 2),
        'hum_range': f'{round(h_min,1)} ~ {round(h_max,1)}%',
        'power_on_ratio': round(power_on/n*100, 1),
    }

def _grade(s):
    """依 pm25/co2 給室內空氣等級"""
    score = 100
    if s['pm25_avg'] > 35: score -= 30
    elif s['pm25_avg'] > 15: score -= 15
    if s['co2_avg']  > 1000: score -= 25
    elif s['co2_avg']  > 800: score -= 10
    if s['voc_avg']  > 2:    score -= 15
    score = max(0, score)
    level = 'A 優良' if score >= 85 else ('B 良好' if score >= 70 else ('C 待改善' if score >= 50 else 'D 不良'))
    return {'score': score, 'level': level}

# 記憶體快取：依 (path, mtime, size) 避免重跑
_CSV_CACHE = {}

def _cached_summarize(path: str):
    try:
        st = os.stat(path)
        key = (path, st.st_mtime_ns, st.st_size)
    except OSError:
        key = (path, 0, 0)
    if key in _CSV_CACHE:
        return _CSV_CACHE[key]
    try:
        r = _summarize_csv(path)
    except Exception as e:
        r = {'error': str(e), 'rows': 0}
    _CSV_CACHE[key] = r
    return r

_FULL_CACHE = {'key': None, 'result': None}

def analyze_all_csv(user: str = 'guest', force: bool = False):
    files = sorted(glob.glob(os.path.join(CSV_DIR, '*.csv')))
    # 全頁結果快取：只要檔案列表與 mtime 未變就直接回傳
    try:
        full_key = tuple((p, os.stat(p).st_mtime_ns) for p in files)
    except OSError:
        full_key = tuple(files)
    if not force and _FULL_CACHE['key'] == full_key and _FULL_CACHE['result']:
        cached = dict(_FULL_CACHE['result'])
        cached['workflow'] = cached['workflow'] + [_step('⚡ 快取命中', '結果來自記憶體快取 (< 5ms)')]
        _audit('csv_analysis', user, {'files': len(files), 'cached': True})
        return cached

    reports = []
    t0 = time.time()
    # 並行讀檔：I/O bound，ThreadPool 即可顯著加速
    with ThreadPoolExecutor(max_workers=min(8, len(files) or 1)) as ex:
        summaries = list(ex.map(_cached_summarize, files))
    for p, s in zip(files, summaries):
        meta = _parse_filename(p)
        if 'error' in s:
            reports.append({**meta, 'summary': s, 'grade': None, 'advice': []})
            continue
        g = _grade(s)
        # 建議
        advice = []
        if s['pm25_avg'] > 35:  advice.append('PM2.5 偏高：建議提升換氣/啟動空氣清淨機')
        if s['co2_avg']  > 1000: advice.append('CO2 偏高：建議增加新風量或定時開窗')
        if s['voc_avg']  > 2:    advice.append('VOC 偏高：檢查裝潢/清潔劑揮發源')
        if s['hum_avg']  > 70:   advice.append('濕度偏高：建議除濕避免黴菌')
        if s['hum_avg']  < 40:   advice.append('濕度偏低：建議加濕維持呼吸舒適')
        if not advice: advice.append('各項指標正常，維持現況')

        # 只輸出遮罩後資訊，真名不外流
        reports.append({
            'room': meta['room'],
            'house': meta['house'],
            'user_masked': meta['user_masked'],
            'user_id': meta['user_id'],
            'summary': s,
            'grade': g,
            'advice': advice,
        })
    # 全公司總覽
    valid = [r for r in reports if r.get('grade')]
    overview = {
        'total_devices': len(reports),
        'total_rows': sum(r['summary'].get('rows', 0) for r in reports),
        'avg_score': round(sum(r['grade']['score'] for r in valid)/max(len(valid),1), 1),
        'worst_pm25': max((r['summary'].get('pm25_avg',0) for r in valid), default=0),
        'worst_co2':  max((r['summary'].get('co2_avg',0)  for r in valid), default=0),
        'analysis_time_ms': int((time.time()-t0)*1000),
    }
    workflow = [
        _step('1. 掃描 CSV 目錄', f'找到 {len(files)} 個檔案 @ {CSV_DIR}'),
        _step('2. PII 去識別化', '檔名中住戶姓名 → 姓氏 + 遮罩 + 雜湊 ID'),
        _step('3. 並行解析時序資料', f'ThreadPool×8 處理 {overview["total_rows"]:,} 筆 / {overview["analysis_time_ms"]}ms'),
        _step('4. 計算空氣品質指標', 'PM2.5/CO2/VOC/溫濕度 均值/極值/超標比'),
        _step('5. AI 等級評分', f'全公司平均 {overview["avg_score"]} 分'),
        _step('6. 個人化建議', '依超標項目生成改善建議'),
        _step('7. 稽核紀錄', '完整操作記錄於 acceptance_audit.jsonl'),
    ]
    result = {'reports': reports, 'overview': overview, 'workflow': workflow}
    _FULL_CACHE['key'] = full_key
    _FULL_CACHE['result'] = result
    _audit('csv_analysis', user, {'files': len(files), 'rows': overview['total_rows']})
    return result

# ============================================================
# 場景 6: microjet E - PII 掃描
# ============================================================
def scan_pii(text: str, user: str = 'guest'):
    findings = []
    patterns = {
        '身分證字號': r'[A-Z][12]\d{8}',
        '手機': r'09\d{2}[-\s]?\d{3}[-\s]?\d{3}',
        'Email': r'[\w\.-]+@[\w\.-]+\.\w+',
        '信用卡': r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
        '地址': r'[\u4e00-\u9fff]{1,3}[市縣][\u4e00-\u9fff]{1,5}[區鄉鎮市]',
        'IP': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
    }
    masked = text
    for name, pat in patterns.items():
        for m in re.finditer(pat, text):
            findings.append({'type': name, 'value_preview': m.group(0)[:3] + '***', 'pos': m.start()})
            masked = masked.replace(m.group(0), '[' + name + '已遮罩]')
    workflow = [
        _step('1. 接收文本', f'長度 {len(text)} 字'),
        _step('2. 套用 6 類 PII 規則', '身分證/手機/Email/卡號/地址/IP'),
        _step('3. 偵測命中', f'共發現 {len(findings)} 處 PII'),
        _step('4. 自動遮罩', '產出可公開分享之版本'),
        _step('5. 稽核紀錄', '不紀錄原文，僅紀錄命中類型數量'),
    ]
    _audit('pii_scan', user, {'n': len(findings), 'types': list(set(f['type'] for f in findings))})
    return {'findings': findings, 'masked_text': masked, 'workflow': workflow}

# ============================================================
# 場景 7: CSV 裝置下鑽（單檔時序迷你聚合）
# ============================================================
def drill_csv(room: str, house: str, bucket_hours: int = 1, max_buckets: int = 48):
    """回傳單一裝置最近 max_buckets 個時段的 PM2.5/CO2/溫濕度 bucket 平均，用於前端畫 chart。"""
    files = glob.glob(os.path.join(CSV_DIR, f'roomId-{room}-houseId-{house}-*.csv'))
    if not files:
        return {'error': f'找不到 roomId={room} houseId={house} 的檔案'}
    path = files[0]
    meta = _parse_filename(path)
    buckets = {}  # key=(yyyy-mm-dd-hour_bucket) → [pm25_sum, co2_sum, t_sum, h_sum, n]
    with open(path, 'r', encoding='utf-8', errors='ignore', newline='') as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if not header: return {'error': '空檔案'}
        idx = {n:i for i,n in enumerate(header)}
        i_dt = idx.get('datetime_local_taipei', 0)
        i_p = idx.get('pm25', -1); i_c = idx.get('co2', -1)
        i_t = idx.get('temperature', -1); i_h = idx.get('humidity', -1)
        for row in reader:
            if len(row) <= i_dt: continue
            dt_s = row[i_dt]
            if len(dt_s) < 13: continue
            # 依 bucket_hours 分桶
            try:
                h = int(dt_s[11:13])
            except Exception:
                continue
            bucket = dt_s[:10] + f' {(h // bucket_hours) * bucket_hours:02d}:00'
            try:
                pm = float(row[i_p] or 0); co = float(row[i_c] or 0)
                t  = float(row[i_t] or 0); hh = float(row[i_h] or 0)
            except (ValueError, IndexError):
                continue
            b = buckets.setdefault(bucket, [0.0, 0.0, 0.0, 0.0, 0])
            b[0]+=pm; b[1]+=co; b[2]+=t; b[3]+=hh; b[4]+=1
    keys = sorted(buckets.keys())[-max_buckets:]
    series = []
    for k in keys:
        b = buckets[k]
        n = b[4] or 1
        series.append({
            'ts': k,
            'pm25': round(b[0]/n, 1),
            'co2':  round(b[1]/n, 0),
            'temp': round(b[2]/n, 1),
            'hum':  round(b[3]/n, 1),
        })
    return {
        'room': room, 'house': house,
        'user_masked': meta['user_masked'],
        'bucket_hours': bucket_hours,
        'series': series,
    }

# ============================================================
# 場景 8: Q&A 多輪對話（會話層）
# ============================================================
_QA_SESSIONS: dict = {}  # sid -> [(role, content)]

def qa_chat_multi(session_id: str, customer: str, question: str, user: str = 'guest'):
    """在既有上下文基礎上回答，每輪仍先走 KB，再由 AI 層補充。"""
    if not session_id:
        session_id = f'qa-{int(time.time()*1000)}'
    history = _QA_SESSIONS.setdefault(session_id, [])
    history.append(('user', question))
    # 以純 KB 層答覆（快速版）
    r = product_qa(customer, question, user)
    history.append(('assistant', r['answer']))
    # 僅保留最近 10 輪
    if len(history) > 20:
        _QA_SESSIONS[session_id] = history[-20:]
    return {
        'session_id': session_id,
        'answer': r['answer'],
        'kb': r['kb'],
        'workflow': r['workflow'],
        'history': [{'role': ro, 'content': c} for ro, c in history],
    }

def qa_session_reset(session_id: str):
    _QA_SESSIONS.pop(session_id, None)
    return {'ok': True}

# ============================================================
# 稽核紀錄讀取
# ============================================================
def read_audit(limit: int = 100):
    if not os.path.exists(AUDIT_LOG):
        return []
    out = []
    with open(AUDIT_LOG, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try: out.append(json.loads(line))
            except: pass
    return out[-limit:][::-1]
